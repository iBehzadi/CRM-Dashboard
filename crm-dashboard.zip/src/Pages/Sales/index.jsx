import { useEffect, useMemo, useState } from "react";
import { FiPlus } from "react-icons/fi";
import { MdOutlineWbSunny } from "react-icons/md";
import useDealStore from "../../Store/dealStore";
import SaleFormModal from "./SaleFormModal";
import useCustomerStore from "../../Store/customerStore";
import { FcClearFilters, FcFilledFilter } from "react-icons/fc";
import { SlBasket } from "react-icons/sl";
import { IoWalletOutline } from "react-icons/io5";

const statusStyles = {
  won: "bg-green-50 text-green-600 dark:bg-green-500/15 dark:text-green-400",
  lost: "bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400",
  waiting:
    "bg-yellow-50 text-yellow-600 dark:bg-yellow-500/15 dark:text-yellow-400",
};

const statusTranslate = {
  won: "موفق",
  lost: "ناموفق",
  waiting: "درانتظار پرداخت",
};

export default function Sales() {
  const deals = useDealStore((state) => state.deals);
  const fetchDeals = useDealStore((state) => state.fetchDeals);
  const [stageFilter, setStageFilter] = useState("all");
  const [showSaleModal, setShowSaleModal] = useState(false);
  const customers = useCustomerStore((state) => state.customers);
  const fetchCustomers = useCustomerStore((state) => state.fetchCustomers);
  const createDeal = useDealStore((state) => state.createDeal);
  const [search, setSearch] = useState("");

  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  // filter and sort
  const sales = useMemo(() => {
    return deals.filter((deal) => {
      const matchSearch =
        (deal.title || "").includes(search) ||
        (deal.customer?.name || "").includes(search);

      if (deal.stage !== "won" && deal.stage !== "lost") {
        return false;
      }

      if (stageFilter !== "all" && deal.stage !== stageFilter) {
        return false;
      }

      if (!deal.closedAt) return false;
      const date = deal.closedAt.slice(0, 10);

      return (
        (!fromDate || date >= fromDate) &&
        (!toDate || date <= toDate) &&
        matchSearch
      );
    });
  }, [deals, stageFilter, fromDate, toDate, search]);

  const summary = useMemo(() => {
    const salesData = deals.filter((dale) => dale.stage === "won");
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const todaySales = salesData.filter((sale) => {
      if (!sale.closedAt) return false;
      const date = new Date(sale.closedAt);

      return (
        date.getDate() === now.getDate() &&
        date.getMonth() === currentMonth &&
        date.getFullYear() === currentYear
      );
    });

    const monthSales = salesData.filter((sale) => {
      if (!sale.closedAt) return false;
      const date = new Date(sale.closedAt);

      return (
        date.getMonth() === currentMonth && date.getFullYear() === currentYear
      );
    });

    const totalTodaySales = todaySales.reduce(
      (total, sale) => total + Number(sale.amount || 0),
      0,
    );

    const totalMonthSales = monthSales.reduce(
      (total, sale) => total + Number(sale.amount || 0),
      0,
    );

    return {
      totalTodaySales,
      totalMonthSales,
      todayCount: todaySales.length,
      monthCount: monthSales.length,
      averageSales: monthSales.length
        ? totalMonthSales / monthSales.length
        : 0,
    };
  }, [deals]);

  useEffect(() => {
    fetchDeals();
    fetchCustomers();
  }, [fetchDeals, fetchCustomers]);

  const formatPrice = (amount) =>
    `${Number(amount || 0).toLocaleString("fa-IR")} تومان`;

  return (
    <div className="space-y-6 text-gray-800 dark:text-slate-100">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-slate-100">
            فروش
          </h1>

          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">
            مدیریت فروش و اطلاعات مشتریان
          </p>
        </div>

        <button
          onClick={() => setShowSaleModal(true)}
          className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-white transition hover:bg-indigo-700"
        >
          <FiPlus />
          ثبت فروش
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            title: "فروش امروز",
            value: formatPrice(summary.totalTodaySales),
            iconBg: "bg-amber-100 dark:bg-amber-500/15",
            iconColor: "text-amber-500 dark:text-amber-400",
            border: "border-amber-200 dark:border-amber-500/20",
            bg: "bg-amber-50 dark:bg-[#172033]",
            icon: MdOutlineWbSunny,
          },
          {
            title: "فروش این ماه",
            value: formatPrice(summary.totalMonthSales),
            iconBg: "bg-blue-100 dark:bg-blue-500/15",
            iconColor: "text-blue-500 dark:text-blue-400",
            border: "border-blue-200 dark:border-blue-500/20",
            bg: "bg-blue-50 dark:bg-[#172033]",
            icon: FcFilledFilter,
          },
          {
            title: "تعداد فروش این ماه",
            value: `${summary.monthCount.toLocaleString("fa-IR")} فروش`,
            iconBg: "bg-green-100 dark:bg-green-500/15",
            iconColor: "text-green-500 dark:text-green-400",
            border: "border-green-200 dark:border-green-500/20",
            bg: "bg-green-50 dark:bg-[#172033]",
            icon: SlBasket,
          },
          {
            title: "میانگین فروش این ماه",
            value: formatPrice(summary.averageSales),
            iconBg: "bg-purple-100 dark:bg-purple-500/15",
            iconColor: "text-purple-500 dark:text-purple-400",
            border: "border-purple-200 dark:border-purple-500/20",
            bg: "bg-purple-50 dark:bg-[#172033]",
            icon: IoWalletOutline,
          },
        ].map((card) => {
          const Icon = card.icon;

          return (
            <div
              key={card.title}
              className={`rounded-xl border ${card.border} ${card.bg} p-4 transition-colors`}
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-medium text-gray-700 dark:text-slate-300">
                  {card.title}
                </h2>

                <Icon
                  className={`h-11 w-11 shrink-0 rounded-full ${card.iconBg} p-2 text-3xl ${card.iconColor}`}
                />
              </div>

              <h3 className="mt-4 wrap-break-word text-lg font-bold text-gray-800 dark:text-slate-100">
                {card.value}
              </h3>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="rounded-xl border border-gray-200 bg-white p-4 dark:border-[#2A3548] dark:bg-[#172033]">
        <div className="flex flex-col gap-3 md:flex-row md:flex-wrap md:items-end">
          <div className="flex flex-col gap-2 text-sm">
            <label
              htmlFor="salesStatus"
              className="text-gray-700 dark:text-slate-300"
            >
              وضعیت
            </label>

            <select
              id="salesStatus"
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value)}
              className="h-10 rounded-lg border border-gray-200 bg-gray-50 px-3 text-gray-800 outline-none focus:ring-2 focus:ring-indigo-500 dark:border-[#2A3548] dark:bg-[#0B1120] dark:text-slate-100"
            >
              <option value="all">همه</option>
              <option value="won">موفق</option>
              <option value="lost">ناموفق</option>
              <option value="waiting">در انتظار پرداخت</option>
            </select>
          </div>

          <div className="flex flex-col gap-2 text-sm">
            <label
              htmlFor="fromDate"
              className="text-gray-700 dark:text-slate-300"
            >
              از تاریخ
            </label>

            <input
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              id="fromDate"
              type="date"
              className="h-10 rounded-lg border border-gray-200 bg-gray-50 px-3 text-gray-800 outline-none focus:ring-2 focus:ring-indigo-500 dark:border-[#2A3548] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          <div className="flex flex-col gap-2 text-sm">
            <label
              htmlFor="toDate"
              className="text-gray-700 dark:text-slate-300"
            >
              تا تاریخ
            </label>

            <input
              value={toDate}
              id="toDate"
              onChange={(e) => setToDate(e.target.value)}
              type="date"
              className="h-10 rounded-lg border border-gray-200 bg-gray-50 px-3 text-gray-800 outline-none focus:ring-2 focus:ring-indigo-500 dark:border-[#2A3548] dark:bg-[#0B1120] dark:text-slate-100"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              setFromDate("");
              setToDate("");
            }}
            className="flex h-10 items-center justify-center gap-2 rounded-lg border border-gray-200 px-4 text-sm text-gray-600 transition hover:border-indigo-400 hover:text-indigo-600 dark:border-[#2A3548] dark:text-slate-300 dark:hover:border-indigo-500 dark:hover:text-indigo-400"
          >
            <FcClearFilters size={20} />
            پاک کردن تاریخ‌ها
          </button>

          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            name=""
            id=""
            placeholder="جستجو نام مشتری یا عنوان محصول ..."
            className="h-10 w-full rounded-lg border border-gray-200 bg-gray-50 pr-3 pl-4 text-gray-800 outline-none focus:ring-2 focus:ring-indigo-500 dark:border-[#2A3548] dark:bg-[#0B1120] dark:text-slate-100 dark:placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Sales table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-[#2A3548] dark:bg-[#172033]">
        <div className="overflow-x-auto">
          <table className="w-full min-w-212.5 text-right">
            <thead className="border-b border-gray-200 bg-gray-50 dark:border-[#2A3548] dark:bg-[#111827]">
              <tr>
                {["مشتری", "عنوان معامله", "مبلغ", "وضعیت", "تاریخ"].map(
                  (title) => (
                    <th
                      key={title}
                      className="px-5 py-4 text-sm font-medium text-gray-500 dark:text-slate-400"
                    >
                      {title}
                    </th>
                  ),
                )}
              </tr>
            </thead>

            <tbody>
              {sales.length > 0 ? (
                sales.map((sale) => (
                  <tr
                    key={sale.documentId}
                    className="border-b border-gray-100 transition last:border-0 hover:bg-gray-50 dark:border-[#2A3548] dark:hover:bg-[#243247]"
                  >
                    <td className="px-5 py-4 font-medium text-gray-800 dark:text-slate-100">
                      {sale.customer?.name || "—"}
                    </td>

                    <td className="px-5 py-4 text-gray-600 dark:text-slate-300">
                      {sale.title || "—"}
                    </td>

                    <td className="whitespace-nowrap px-5 py-4 text-gray-700 dark:text-slate-200">
                      {formatPrice(sale.amount)}
                    </td>

                    <td className="px-5 py-4">
                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${statusStyles[sale.stage]}`}
                      >
                        {statusTranslate[sale.stage]}
                      </span>
                    </td>

                    <td className="whitespace-nowrap px-5 py-4 text-gray-500 dark:text-slate-400">
                      {sale.closedAt || "—"}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={6}
                    className="px-5 py-10 text-center text-sm text-gray-500 dark:text-slate-400"
                  >
                    هنوز فروش موفقی ثبت نشده است.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showSaleModal && (
        <SaleFormModal
          customers={customers}
          onClose={() => setShowSaleModal(false)}
          onCreate={async (payload) => await createDeal(payload)}
        />
      )}
    </div>
  );
}